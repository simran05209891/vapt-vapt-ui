function Loader() {

    return (

        <p>LogInin.....</p>
    );
}


export default Loader;